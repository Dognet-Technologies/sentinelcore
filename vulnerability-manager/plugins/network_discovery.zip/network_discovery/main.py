#!/usr/bin/env python3
"""
Network Discovery Plugin for Vulnerability Manager
Discovers alive hosts and builds network topology
"""

import json
import sys
import argparse
import ipaddress
import subprocess
import platform
import concurrent.futures
from typing import Dict, List, Any, Optional
import socket
import re
from datetime import datetime

class NetworkDiscovery:
    def __init__(self):
        self.os_type = platform.system().lower()
        self.ping_cmd = self._get_ping_command()
        
    def _get_ping_command(self) -> List[str]:
        """Get OS-specific ping command"""
        if self.os_type == "windows":
            return ["ping", "-n", "1", "-w", "1000"]
        else:  # Linux/Mac
            return ["ping", "-c", "1", "-W", "1"]
    
    def ping_host(self, ip: str) -> Optional[Dict[str, Any]]:
        """Ping single host and return info if alive"""
        try:
            cmd = self.ping_cmd + [ip]
            result = subprocess.run(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=2
            )
            
            if result.returncode == 0:
                # Try to get hostname
                try:
                    hostname = socket.gethostbyaddr(ip)[0]
                except:
                    hostname = None
                
                # Extract TTL for OS fingerprinting
                output = result.stdout.decode()
                ttl = self._extract_ttl(output)
                os_guess = self._guess_os_by_ttl(ttl)
                
                return {
                    "ip": ip,
                    "hostname": hostname,
                    "alive": True,
                    "ttl": ttl,
                    "os_guess": os_guess,
                    "timestamp": datetime.utcnow().isoformat()
                }
        except:
            pass
        return None
    
    def _extract_ttl(self, ping_output: str) -> Optional[int]:
        """Extract TTL from ping output"""
        ttl_pattern = r"ttl=(\d+)"
        match = re.search(ttl_pattern, ping_output, re.IGNORECASE)
        if match:
            return int(match.group(1))
        return None
    
    def _guess_os_by_ttl(self, ttl: Optional[int]) -> str:
        """Guess OS based on TTL value"""
        if not ttl:
            return "Unknown"
        
        # Common default TTL values
        if ttl <= 64:
            return "Linux/Unix"
        elif ttl <= 128:
            return "Windows"
        elif ttl <= 255:
            return "Network Device"
        return "Unknown"
    
    def scan_network(self, network: str, max_workers: int = 50) -> List[Dict[str, Any]]:
        """Scan network range for alive hosts"""
        try:
            net = ipaddress.ip_network(network, strict=False)
            hosts = []
            
            # Use thread pool for concurrent pinging
            with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
                # Submit all ping tasks
                future_to_ip = {
                    executor.submit(self.ping_host, str(ip)): str(ip)
                    for ip in net.hosts()
                }
                
                # Collect results
                for future in concurrent.futures.as_completed(future_to_ip):
                    result = future.result()
                    if result:
                        hosts.append(result)
            
            return hosts
        except Exception as e:
            raise Exception(f"Network scan failed: {str(e)}")
    
    def get_network_topology(self, hosts: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Build network topology from discovered hosts"""
        # Group hosts by subnet
        subnets = {}
        for host in hosts:
            ip = ipaddress.ip_address(host["ip"])
            # Get /24 subnet
            subnet = str(ipaddress.ip_network(f"{ip}/24", strict=False))
            
            if subnet not in subnets:
                subnets[subnet] = []
            subnets[subnet].append(host)
        
        # Build topology
        topology = {
            "nodes": [],
            "edges": [],
            "stats": {
                "total_hosts": len(hosts),
                "total_subnets": len(subnets),
                "scan_time": datetime.utcnow().isoformat()
            }
        }
        
        # Add subnet nodes
        for subnet, subnet_hosts in subnets.items():
            subnet_node = {
                "id": f"subnet_{subnet}",
                "type": "subnet",
                "label": subnet,
                "host_count": len(subnet_hosts)
            }
            topology["nodes"].append(subnet_node)
            
            # Add host nodes and edges
            for host in subnet_hosts:
                host_node = {
                    "id": f"host_{host['ip']}",
                    "type": "host",
                    "label": host["hostname"] or host["ip"],
                    "ip": host["ip"],
                    "os_guess": host["os_guess"],
                    "ttl": host["ttl"]
                }
                topology["nodes"].append(host_node)
                
                # Add edge from subnet to host
                edge = {
                    "source": f"subnet_{subnet}",
                    "target": f"host_{host['ip']}"
                }
                topology["edges"].append(edge)
        
        return topology

def main():
    """Plugin entry point"""
    parser = argparse.ArgumentParser()
    parser.add_argument("--request", required=True, help="JSON request")
    args = parser.parse_args()
    
    try:
        # Parse request
        request = json.loads(args.request)
        action = request.get("action")
        data = request.get("data", {})
        
        discovery = NetworkDiscovery()
        
        if action == "scan":
            # Scan network
            network = data.get("network", "192.168.1.0/24")
            max_workers = data.get("max_workers", 50)
            
            hosts = discovery.scan_network(network, max_workers)
            topology = discovery.get_network_topology(hosts)
            
            response = {
                "success": True,
                "data": {
                    "hosts": hosts,
                    "topology": topology
                }
            }
        
        elif action == "ping":
            # Ping single host
            ip = data.get("ip")
            if not ip:
                raise ValueError("IP address required")
            
            result = discovery.ping_host(ip)
            response = {
                "success": True,
                "data": result
            }
        
        elif action == "info":
            # Plugin info
            response = {
                "success": True,
                "data": {
                    "name": "network_discovery",
                    "version": "1.0.0",
                    "author": "Dognet Technologies",
                    "description": "Network discovery and topology mapping",
                    "capabilities": ["scan", "ping", "topology"]
                }
            }
        
        else:
            response = {
                "success": False,
                "error": f"Unknown action: {action}"
            }
    
    except Exception as e:
        response = {
            "success": False,
            "error": str(e)
        }
    
    # Output response
    print(json.dumps(response))

if __name__ == "__main__":
    main()