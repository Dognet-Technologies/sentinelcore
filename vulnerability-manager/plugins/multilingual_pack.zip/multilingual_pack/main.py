#!/usr/bin/env python3
"""
Multilingual Pack Plugin
Provides translations for English, Spanish, and Portuguese
"""

import json
import sys
import argparse
from typing import Dict, List, Any, Optional


TRANSLATIONS = {
    "en": {
        "app": {
            "title": "SentinelCore Vulnerability Manager",
            "subtitle": "Enterprise Security Management Platform",
            "version": "Version"
        },
        "navigation": {
            "dashboard": "Dashboard",
            "vulnerabilities": "Vulnerabilities",
            "assets": "Assets",
            "reports": "Reports",
            "settings": "Settings",
            "teams": "Teams",
            "plugins": "Plugins",
            "logout": "Logout"
        },
        "common": {
            "loading": "Loading...",
            "error": "Error",
            "success": "Success",
            "cancel": "Cancel",
            "save": "Save",
            "delete": "Delete",
            "edit": "Edit",
            "add": "Add",
            "close": "Close",
            "search": "Search",
            "filter": "Filter",
            "export": "Export",
            "import": "Import",
            "refresh": "Refresh",
            "back": "Back",
            "next": "Next",
            "previous": "Previous"
        },
        "vulnerabilities": {
            "title": "Vulnerabilities",
            "critical": "Critical",
            "high": "High",
            "medium": "Medium",
            "low": "Low",
            "info": "Informational",
            "severity": "Severity",
            "cvss_score": "CVSS Score",
            "status": "Status",
            "open": "Open",
            "closed": "Closed",
            "in_progress": "In Progress",
            "remediation": "Remediation",
            "description": "Description",
            "affected_assets": "Affected Assets",
            "created_date": "Created Date",
            "last_updated": "Last Updated"
        },
        "dashboard": {
            "welcome": "Welcome",
            "overview": "Overview",
            "recent_vulnerabilities": "Recent Vulnerabilities",
            "critical_assets": "Critical Assets",
            "status_summary": "Status Summary",
            "compliance": "Compliance"
        },
        "assets": {
            "title": "Assets",
            "hostname": "Hostname",
            "ip_address": "IP Address",
            "os": "Operating System",
            "vulnerability_count": "Vulnerability Count",
            "risk_level": "Risk Level",
            "last_scan": "Last Scan"
        },
        "reports": {
            "title": "Reports",
            "generate": "Generate Report",
            "executive_summary": "Executive Summary",
            "technical_report": "Technical Report",
            "compliance_report": "Compliance Report",
            "export_format": "Export Format"
        },
        "settings": {
            "title": "Settings",
            "general": "General",
            "security": "Security",
            "notifications": "Notifications",
            "integrations": "Integrations",
            "profile": "Profile",
            "theme": "Theme",
            "language": "Language"
        },
        "teams": {
            "title": "Teams",
            "members": "Members",
            "roles": "Roles",
            "permissions": "Permissions",
            "invite": "Invite Member",
            "remove": "Remove Member"
        },
        "auth": {
            "login": "Login",
            "logout": "Logout",
            "username": "Username",
            "password": "Password",
            "email": "Email",
            "remember_me": "Remember Me",
            "forgot_password": "Forgot Password?",
            "invalid_credentials": "Invalid credentials",
            "session_expired": "Session expired"
        }
    },
    "es": {
        "app": {
            "title": "Gestor de Vulnerabilidades SentinelCore",
            "subtitle": "Plataforma de Gestión de Seguridad Empresarial",
            "version": "Versión"
        },
        "navigation": {
            "dashboard": "Panel de Control",
            "vulnerabilities": "Vulnerabilidades",
            "assets": "Activos",
            "reports": "Informes",
            "settings": "Configuración",
            "teams": "Equipos",
            "plugins": "Complementos",
            "logout": "Cerrar Sesión"
        },
        "common": {
            "loading": "Cargando...",
            "error": "Error",
            "success": "Éxito",
            "cancel": "Cancelar",
            "save": "Guardar",
            "delete": "Eliminar",
            "edit": "Editar",
            "add": "Agregar",
            "close": "Cerrar",
            "search": "Buscar",
            "filter": "Filtrar",
            "export": "Exportar",
            "import": "Importar",
            "refresh": "Actualizar",
            "back": "Atrás",
            "next": "Siguiente",
            "previous": "Anterior"
        },
        "vulnerabilities": {
            "title": "Vulnerabilidades",
            "critical": "Crítica",
            "high": "Alta",
            "medium": "Media",
            "low": "Baja",
            "info": "Informativa",
            "severity": "Gravedad",
            "cvss_score": "Puntuación CVSS",
            "status": "Estado",
            "open": "Abierta",
            "closed": "Cerrada",
            "in_progress": "En Progreso",
            "remediation": "Remediación",
            "description": "Descripción",
            "affected_assets": "Activos Afectados",
            "created_date": "Fecha de Creación",
            "last_updated": "Última Actualización"
        },
        "dashboard": {
            "welcome": "Bienvenido",
            "overview": "Descripción General",
            "recent_vulnerabilities": "Vulnerabilidades Recientes",
            "critical_assets": "Activos Críticos",
            "status_summary": "Resumen de Estado",
            "compliance": "Cumplimiento"
        },
        "assets": {
            "title": "Activos",
            "hostname": "Nombre de Host",
            "ip_address": "Dirección IP",
            "os": "Sistema Operativo",
            "vulnerability_count": "Cantidad de Vulnerabilidades",
            "risk_level": "Nivel de Riesgo",
            "last_scan": "Último Escaneo"
        },
        "reports": {
            "title": "Informes",
            "generate": "Generar Informe",
            "executive_summary": "Resumen Ejecutivo",
            "technical_report": "Informe Técnico",
            "compliance_report": "Informe de Cumplimiento",
            "export_format": "Formato de Exportación"
        },
        "settings": {
            "title": "Configuración",
            "general": "General",
            "security": "Seguridad",
            "notifications": "Notificaciones",
            "integrations": "Integraciones",
            "profile": "Perfil",
            "theme": "Tema",
            "language": "Idioma"
        },
        "teams": {
            "title": "Equipos",
            "members": "Miembros",
            "roles": "Roles",
            "permissions": "Permisos",
            "invite": "Invitar Miembro",
            "remove": "Eliminar Miembro"
        },
        "auth": {
            "login": "Iniciar Sesión",
            "logout": "Cerrar Sesión",
            "username": "Nombre de Usuario",
            "password": "Contraseña",
            "email": "Correo Electrónico",
            "remember_me": "Recuérdame",
            "forgot_password": "¿Olvidó su contraseña?",
            "invalid_credentials": "Credenciales inválidas",
            "session_expired": "Sesión expirada"
        }
    },
    "pt": {
        "app": {
            "title": "Gerenciador de Vulnerabilidades SentinelCore",
            "subtitle": "Plataforma de Gerenciamento de Segurança Corporativa",
            "version": "Versão"
        },
        "navigation": {
            "dashboard": "Painel",
            "vulnerabilities": "Vulnerabilidades",
            "assets": "Ativos",
            "reports": "Relatórios",
            "settings": "Configurações",
            "teams": "Equipes",
            "plugins": "Plug-ins",
            "logout": "Sair"
        },
        "common": {
            "loading": "Carregando...",
            "error": "Erro",
            "success": "Sucesso",
            "cancel": "Cancelar",
            "save": "Salvar",
            "delete": "Excluir",
            "edit": "Editar",
            "add": "Adicionar",
            "close": "Fechar",
            "search": "Pesquisar",
            "filter": "Filtrar",
            "export": "Exportar",
            "import": "Importar",
            "refresh": "Atualizar",
            "back": "Voltar",
            "next": "Próximo",
            "previous": "Anterior"
        },
        "vulnerabilities": {
            "title": "Vulnerabilidades",
            "critical": "Crítica",
            "high": "Alta",
            "medium": "Média",
            "low": "Baixa",
            "info": "Informativa",
            "severity": "Severidade",
            "cvss_score": "Pontuação CVSS",
            "status": "Status",
            "open": "Aberta",
            "closed": "Fechada",
            "in_progress": "Em Progresso",
            "remediation": "Remediação",
            "description": "Descrição",
            "affected_assets": "Ativos Afetados",
            "created_date": "Data de Criação",
            "last_updated": "Última Atualização"
        },
        "dashboard": {
            "welcome": "Bem-vindo",
            "overview": "Visão Geral",
            "recent_vulnerabilities": "Vulnerabilidades Recentes",
            "critical_assets": "Ativos Críticos",
            "status_summary": "Resumo de Status",
            "compliance": "Conformidade"
        },
        "assets": {
            "title": "Ativos",
            "hostname": "Nome do Host",
            "ip_address": "Endereço IP",
            "os": "Sistema Operacional",
            "vulnerability_count": "Contagem de Vulnerabilidades",
            "risk_level": "Nível de Risco",
            "last_scan": "Último Verificado"
        },
        "reports": {
            "title": "Relatórios",
            "generate": "Gerar Relatório",
            "executive_summary": "Resumo Executivo",
            "technical_report": "Relatório Técnico",
            "compliance_report": "Relatório de Conformidade",
            "export_format": "Formato de Exportação"
        },
        "settings": {
            "title": "Configurações",
            "general": "Geral",
            "security": "Segurança",
            "notifications": "Notificações",
            "integrations": "Integrações",
            "profile": "Perfil",
            "theme": "Tema",
            "language": "Idioma"
        },
        "teams": {
            "title": "Equipes",
            "members": "Membros",
            "roles": "Funções",
            "permissions": "Permissões",
            "invite": "Convidar Membro",
            "remove": "Remover Membro"
        },
        "auth": {
            "login": "Login",
            "logout": "Sair",
            "username": "Nome de Usuário",
            "password": "Senha",
            "email": "E-mail",
            "remember_me": "Lembrar-me",
            "forgot_password": "Esqueceu a senha?",
            "invalid_credentials": "Credenciais inválidas",
            "session_expired": "Sessão expirada"
        }
    }
}


class MultilingualManager:
    def __init__(self):
        self.translations = TRANSLATIONS
        self.supported_languages = list(TRANSLATIONS.keys())
        self.default_language = "en"
    
    def list_languages(self) -> List[Dict[str, Any]]:
        """List all available languages"""
        return [
            {
                "code": lang_code,
                "name": self._get_language_name(lang_code),
                "native_name": self._get_native_language_name(lang_code),
                "supported": True
            }
            for lang_code in self.supported_languages
        ]
    
    def get_translations(self, language: str) -> Optional[Dict[str, Any]]:
        """Get all translations for specific language"""
        if language not in self.translations:
            language = self.default_language
        
        return self.translations[language]
    
    def get_string(self, language: str, key: str, default: str = None) -> str:
        """Get translated string by key (e.g., 'common.loading')"""
        if language not in self.translations:
            language = self.default_language
        
        translations = self.translations[language]
        parts = key.split(".")
        
        try:
            value = translations
            for part in parts:
                value = value[part]
            return value
        except (KeyError, TypeError):
            # Fallback to English
            if language != self.default_language:
                return self.get_string(self.default_language, key, default)
            return default or key
    
    def validate_language(self, language_code: str) -> Dict[str, Any]:
        """Validate if language code is supported"""
        return {
            "code": language_code,
            "supported": language_code in self.supported_languages,
            "available_languages": self.supported_languages
        }
    
    def get_language_stats(self) -> Dict[str, Any]:
        """Get statistics about translations"""
        stats = {}
        for lang_code in self.supported_languages:
            lang_translations = self.translations[lang_code]
            stats[lang_code] = self._count_translations(lang_translations)
        
        return stats
    
    def _count_translations(self, obj: Any, count: int = 0) -> int:
        """Recursively count translation keys"""
        if isinstance(obj, dict):
            for value in obj.values():
                count += self._count_translations(value, count)
        else:
            count += 1
        return count
    
    def _get_language_name(self, lang_code: str) -> str:
        """Get language name in English"""
        names = {
            "en": "English",
            "es": "Spanish",
            "pt": "Portuguese"
        }
        return names.get(lang_code, lang_code.upper())
    
    def _get_native_language_name(self, lang_code: str) -> str:
        """Get native language name"""
        names = {
            "en": "English",
            "es": "Español",
            "pt": "Português"
        }
        return names.get(lang_code, lang_code.upper())


def main():
    """Plugin entry point"""
    parser = argparse.ArgumentParser()
    parser.add_argument("--request", required=True, help="JSON request")
    args = parser.parse_args()
    
    try:
        # Parse request
        request = json.loads(args.request)
        action = request.get("action")
        data = request.get("data", {})
        
        manager = MultilingualManager()
        
        if action == "list_languages":
            languages = manager.list_languages()
            response = {
                "success": True,
                "data": {
                    "languages": languages,
                    "count": len(languages)
                }
            }
        
        elif action == "get_translations":
            language = data.get("language", "en")
            translations = manager.get_translations(language)
            response = {
                "success": True,
                "data": {
                    "language": language,
                    "translations": translations
                }
            }
        
        elif action == "get_string":
            language = data.get("language", "en")
            key = data.get("key")
            default = data.get("default")
            
            if not key:
                raise ValueError("key is required")
            
            string = manager.get_string(language, key, default)
            response = {
                "success": True,
                "data": {
                    "language": language,
                    "key": key,
                    "value": string
                }
            }
        
        elif action == "validate_language":
            language = data.get("language")
            if not language:
                raise ValueError("language is required")
            
            validation = manager.validate_language(language)
            response = {
                "success": validation["supported"],
                "data": validation
            }
        
        elif action == "stats":
            stats = manager.get_language_stats()
            response = {
                "success": True,
                "data": {
                    "stats": stats,
                    "default_language": manager.default_language,
                    "supported_languages": manager.supported_languages
                }
            }
        
        elif action == "info":
            response = {
                "success": True,
                "data": {
                    "name": "multilingual_pack",
                    "version": "1.0.0",
                    "author": "SentinelCore Team",
                    "description": "Provides multilingual support with translations",
                    "supported_languages": manager.supported_languages,
                    "default_language": manager.default_language,
                    "capabilities": ["list_languages", "get_translations", "get_string", "validate_language", "stats"]
                }
            }
        
        else:
            response = {
                "success": False,
                "error": f"Unknown action: {action}"
            }
    
    except Exception as e:
        response = {
            "success": False,
            "error": str(e)
        }
    
    # Output response
    print(json.dumps(response))


if __name__ == "__main__":
    main()
