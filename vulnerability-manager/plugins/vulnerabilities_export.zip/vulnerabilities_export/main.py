#!/usr/bin/env python3
"""
Vulnerabilities Export Plugin
Exports vulnerabilities in multiple formats: CSV, XML, Excel, ODS
"""

import json
import sys
import argparse
import csv
import xml.etree.ElementTree as ET
from datetime import datetime
from io import StringIO, BytesIO
from typing import Dict, List, Any, Optional

try:
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment
    HAS_OPENPYXL = True
except ImportError:
    HAS_OPENPYXL = False

try:
    from odf.opendocument import OpenDocumentSpreadsheet
    from odf.table import Table, TableRow, TableCell
    from odf.text import P
    HAS_ODF = True
except ImportError:
    HAS_ODF = False


class VulnerabilitiesExporter:
    def __init__(self):
        self.timestamp = datetime.utcnow().isoformat()
        
    def export_csv(self, vulnerabilities: List[Dict[str, Any]]) -> str:
        """Export vulnerabilities to CSV format"""
        if not vulnerabilities:
            return ""
        
        output = StringIO()
        
        # Flatten all vulnerabilities first to get all fieldnames
        flat_vulns = [self._flatten_dict(vuln) for vuln in vulnerabilities]
        
        # Get all unique keys from flattened data
        fieldnames = set()
        for flat_vuln in flat_vulns:
            fieldnames.update(flat_vuln.keys())
        fieldnames = sorted(list(fieldnames))
        
        writer = csv.DictWriter(output, fieldnames=fieldnames, restval="", extrasaction='ignore')
        writer.writeheader()
        
        for flat_vuln in flat_vulns:
            writer.writerow(flat_vuln)
        
        return output.getvalue()
    
    def export_xml(self, vulnerabilities: List[Dict[str, Any]]) -> str:
        """Export vulnerabilities to XML format"""
        root = ET.Element("vulnerabilities")
        root.set("count", str(len(vulnerabilities)))
        root.set("exported", self.timestamp)
        
        for vuln in vulnerabilities:
            vuln_elem = ET.SubElement(root, "vulnerability")
            self._dict_to_xml(vuln, vuln_elem)
        
        # Pretty print XML
        xml_str = ET.tostring(root, encoding='unicode')
        # Simple pretty print
        return self._pretty_xml(xml_str)
    
    def export_excel(self, vulnerabilities: List[Dict[str, Any]]) -> bytes:
        """Export vulnerabilities to Excel format"""
        if not HAS_OPENPYXL:
            raise Exception("openpyxl not installed. Install with: pip install openpyxl>=3.10.0")
        
        workbook = Workbook()
        worksheet = workbook.active
        worksheet.title = "Vulnerabilities"
        
        # Get all unique keys
        fieldnames = set()
        for vuln in vulnerabilities:
            fieldnames.update(vuln.keys())
        fieldnames = sorted(list(fieldnames))
        
        # Write header
        header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
        header_font = Font(bold=True, color="FFFFFF")
        
        for col_idx, field in enumerate(fieldnames, 1):
            cell = worksheet.cell(row=1, column=col_idx)
            cell.value = field
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(horizontal="center", vertical="center")
        
        # Write data
        for row_idx, vuln in enumerate(vulnerabilities, 2):
            flat_vuln = self._flatten_dict(vuln)
            for col_idx, field in enumerate(fieldnames, 1):
                cell = worksheet.cell(row=row_idx, column=col_idx)
                cell.value = flat_vuln.get(field, "")
                cell.alignment = Alignment(wrap_text=True)
        
        # Auto-adjust column widths
        for col_idx, field in enumerate(fieldnames, 1):
            max_length = min(50, max(
                len(str(field)),
                max([len(str(vuln.get(field, ""))) for vuln in vulnerabilities], default=0)
            ))
            worksheet.column_dimensions[self._col_letter(col_idx)].width = max_length + 2
        
        # Save to bytes
        output = BytesIO()
        workbook.save(output)
        output.seek(0)
        return output.getvalue()
    
    def export_ods(self, vulnerabilities: List[Dict[str, Any]]) -> bytes:
        """Export vulnerabilities to OpenOffice format"""
        if not HAS_ODF:
            raise Exception("odfpy not installed. Install with: pip install odfpy>=1.4.1")
        
        doc = OpenDocumentSpreadsheet()
        table = Table(name="Vulnerabilities")
        doc.spreadsheet.addElement(table)
        
        # Get fieldnames
        fieldnames = set()
        for vuln in vulnerabilities:
            fieldnames.update(vuln.keys())
        fieldnames = sorted(list(fieldnames))
        
        # Write header row
        header_row = TableRow()
        for field in fieldnames:
            cell = TableCell(valuetype="string")
            cell.addElement(P(text=field))
            header_row.addElement(cell)
        table.addElement(header_row)
        
        # Write data rows
        for vuln in vulnerabilities:
            flat_vuln = self._flatten_dict(vuln)
            row = TableRow()
            for field in fieldnames:
                cell = TableCell(valuetype="string")
                cell.addElement(P(text=str(flat_vuln.get(field, ""))))
                row.addElement(cell)
            table.addElement(row)
        
        # Save to bytes
        output = BytesIO()
        doc.save(output)
        output.seek(0)
        return output.getvalue()
    
    def _flatten_dict(self, d: Dict, parent_key: str = '', sep: str = '_') -> Dict:
        """Flatten nested dictionary"""
        items = []
        for k, v in d.items():
            new_key = f"{parent_key}{sep}{k}" if parent_key else k
            if isinstance(v, dict):
                items.extend(self._flatten_dict(v, new_key, sep=sep).items())
            elif isinstance(v, list):
                items.append((new_key, json.dumps(v)))
            else:
                items.append((new_key, v))
        return dict(items)
    
    def _dict_to_xml(self, data: Dict, parent: ET.Element) -> None:
        """Convert dictionary to XML elements"""
        for key, value in data.items():
            # Sanitize key
            key = str(key).replace(" ", "_").replace("-", "_")
            
            if isinstance(value, dict):
                elem = ET.SubElement(parent, key)
                self._dict_to_xml(value, elem)
            elif isinstance(value, list):
                for item in value:
                    elem = ET.SubElement(parent, key)
                    if isinstance(item, dict):
                        self._dict_to_xml(item, elem)
                    else:
                        elem.text = str(item)
            else:
                elem = ET.SubElement(parent, key)
                elem.text = str(value) if value is not None else ""
    
    def _pretty_xml(self, xml_str: str) -> str:
        """Pretty print XML string"""
        import xml.dom.minidom
        try:
            dom = xml.dom.minidom.parseString(xml_str)
            return dom.toprettyxml(indent="  ")
        except:
            return xml_str
    
    def _col_letter(self, col: int) -> str:
        """Convert column number to letter"""
        result = ""
        while col > 0:
            col -= 1
            result = chr(65 + col % 26) + result
            col //= 26
        return result


def main():
    """Plugin entry point"""
    parser = argparse.ArgumentParser()
    parser.add_argument("--request", required=True, help="JSON request")
    args = parser.parse_args()
    
    try:
        # Parse request
        request = json.loads(args.request)
        action = request.get("action")
        data = request.get("data", {})
        
        exporter = VulnerabilitiesExporter()
        vulnerabilities = data.get("vulnerabilities", [])
        format_type = data.get("format", "csv")
        
        if action == "export_csv":
            content = exporter.export_csv(vulnerabilities)
            response = {
                "success": True,
                "data": {
                    "format": "csv",
                    "content": content,
                    "filename": f"vulnerabilities_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.csv",
                    "count": len(vulnerabilities)
                }
            }
        
        elif action == "export_xml":
            content = exporter.export_xml(vulnerabilities)
            response = {
                "success": True,
                "data": {
                    "format": "xml",
                    "content": content,
                    "filename": f"vulnerabilities_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.xml",
                    "count": len(vulnerabilities)
                }
            }
        
        elif action == "export_excel":
            content = exporter.export_excel(vulnerabilities)
            # Convert bytes to base64 for JSON transmission
            import base64
            content_b64 = base64.b64encode(content).decode('utf-8')
            response = {
                "success": True,
                "data": {
                    "format": "excel",
                    "content_base64": content_b64,
                    "filename": f"vulnerabilities_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.xlsx",
                    "count": len(vulnerabilities)
                }
            }
        
        elif action == "export_ods":
            content = exporter.export_ods(vulnerabilities)
            import base64
            content_b64 = base64.b64encode(content).decode('utf-8')
            response = {
                "success": True,
                "data": {
                    "format": "ods",
                    "content_base64": content_b64,
                    "filename": f"vulnerabilities_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.ods",
                    "count": len(vulnerabilities)
                }
            }
        
        elif action == "info":
            response = {
                "success": True,
                "data": {
                    "name": "vulnerabilities_export",
                    "version": "1.0.0",
                    "author": "SentinelCore Team",
                    "description": "Exports vulnerabilities in multiple formats",
                    "formats": ["csv", "xml", "excel", "ods"],
                    "capabilities": ["export_csv", "export_xml", "export_excel", "export_ods"]
                }
            }
        
        else:
            response = {
                "success": False,
                "error": f"Unknown action: {action}"
            }
    
    except Exception as e:
        response = {
            "success": False,
            "error": str(e)
        }
    
    # Output response
    print(json.dumps(response))


if __name__ == "__main__":
    main()
