#!/usr/bin/env python3
"""
Themes Extension Plugin
Provides additional UI themes and color schemes
"""

import json
import sys
import argparse
from typing import Dict, List, Any, Optional


BUILT_IN_THEMES = {
    "modern_dark": {
        "id": "modern_dark",
        "name": "Modern Dark",
        "description": "Modern dark theme with blue accents",
        "isDark": True,
        "palette": {
            "primary": {
                "main": "#2196F3",
                "light": "#64B5F6",
                "dark": "#1976D2"
            },
            "secondary": {
                "main": "#FF4081",
                "light": "#FF6E99",
                "dark": "#F50057"
            },
            "background": {
                "default": "#121212",
                "paper": "#1E1E1E"
            },
            "text": {
                "primary": "#FFFFFF",
                "secondary": "#B0B0B0"
            },
            "success": "#4CAF50",
            "warning": "#FFC107",
            "error": "#F44336",
            "info": "#2196F3"
        },
        "typography": {
            "fontFamily": "Inter, -apple-system, BlinkMacSystemFont, Segoe UI",
            "fontSize": 14,
            "fontWeightLight": 300,
            "fontWeightRegular": 400,
            "fontWeightMedium": 500,
            "fontWeightBold": 700
        },
        "borderRadius": 8,
        "spacing": 8
    },
    "modern_light": {
        "id": "modern_light",
        "name": "Modern Light",
        "description": "Modern light theme with blue accents",
        "isDark": False,
        "palette": {
            "primary": {
                "main": "#1976D2",
                "light": "#42A5F5",
                "dark": "#1565C0"
            },
            "secondary": {
                "main": "#DC004E",
                "light": "#F05545",
                "dark": "#9A0036"
            },
            "background": {
                "default": "#FAFAFA",
                "paper": "#FFFFFF"
            },
            "text": {
                "primary": "#212121",
                "secondary": "#757575"
            },
            "success": "#388E3C",
            "warning": "#F57C00",
            "error": "#D32F2F",
            "info": "#1976D2"
        },
        "typography": {
            "fontFamily": "Inter, -apple-system, BlinkMacSystemFont, Segoe UI",
            "fontSize": 14,
            "fontWeightLight": 300,
            "fontWeightRegular": 400,
            "fontWeightMedium": 500,
            "fontWeightBold": 700
        },
        "borderRadius": 8,
        "spacing": 8
    },
    "cyberpunk": {
        "id": "cyberpunk",
        "name": "Cyberpunk",
        "description": "Futuristic cyberpunk theme with neon colors",
        "isDark": True,
        "palette": {
            "primary": {
                "main": "#00FF00",
                "light": "#00FF88",
                "dark": "#00BB00"
            },
            "secondary": {
                "main": "#FF00FF",
                "light": "#FF88FF",
                "dark": "#BB00BB"
            },
            "background": {
                "default": "#0A0E27",
                "paper": "#151B3A"
            },
            "text": {
                "primary": "#00FF00",
                "secondary": "#00BB00"
            },
            "success": "#00FF00",
            "warning": "#FFFF00",
            "error": "#FF0055",
            "info": "#00FFFF"
        },
        "typography": {
            "fontFamily": "'Space Mono', monospace",
            "fontSize": 14,
            "fontWeightLight": 300,
            "fontWeightRegular": 400,
            "fontWeightMedium": 500,
            "fontWeightBold": 700
        },
        "borderRadius": 2,
        "spacing": 8
    },
    "solarized_dark": {
        "id": "solarized_dark",
        "name": "Solarized Dark",
        "description": "Solarized dark color scheme",
        "isDark": True,
        "palette": {
            "primary": {
                "main": "#268BD2",
                "light": "#69B7F0",
                "dark": "#1E6BA8"
            },
            "secondary": {
                "main": "#2AA198",
                "light": "#7CCCC8",
                "dark": "#1F7F76"
            },
            "background": {
                "default": "#002B36",
                "paper": "#073642"
            },
            "text": {
                "primary": "#93A1A1",
                "secondary": "#839496"
            },
            "success": "#859900",
            "warning": "#B58900",
            "error": "#DC322F",
            "info": "#268BD2"
        },
        "typography": {
            "fontFamily": "Menlo, Monaco, 'Courier New', monospace",
            "fontSize": 14,
            "fontWeightLight": 300,
            "fontWeightRegular": 400,
            "fontWeightMedium": 500,
            "fontWeightBold": 700
        },
        "borderRadius": 4,
        "spacing": 8
    },
    "nord": {
        "id": "nord",
        "name": "Nord",
        "description": "Arctic, north-bluish color scheme",
        "isDark": True,
        "palette": {
            "primary": {
                "main": "#88C0D0",
                "light": "#B3E5FC",
                "dark": "#5B9DB1"
            },
            "secondary": {
                "main": "#81A1C1",
                "light": "#A8D8F0",
                "dark": "#5A7A8F"
            },
            "background": {
                "default": "#2E3440",
                "paper": "#3B4252"
            },
            "text": {
                "primary": "#ECEFF4",
                "secondary": "#D8DEE9"
            },
            "success": "#A3BE8C",
            "warning": "#EBCB8B",
            "error": "#BF616A",
            "info": "#88C0D0"
        },
        "typography": {
            "fontFamily": "Inter, -apple-system, BlinkMacSystemFont, Segoe UI",
            "fontSize": 14,
            "fontWeightLight": 300,
            "fontWeightRegular": 400,
            "fontWeightMedium": 500,
            "fontWeightBold": 700
        },
        "borderRadius": 6,
        "spacing": 8
    },
    "dracula": {
        "id": "dracula",
        "name": "Dracula",
        "description": "Dark theme inspired by Dracula color scheme",
        "isDark": True,
        "palette": {
            "primary": {
                "main": "#BD93F9",
                "light": "#D7B8FF",
                "dark": "#9967D4"
            },
            "secondary": {
                "main": "#FF79C6",
                "light": "#FF9FD8",
                "dark": "#E5669E"
            },
            "background": {
                "default": "#282A36",
                "paper": "#3B3F4B"
            },
            "text": {
                "primary": "#F8F8F2",
                "secondary": "#D8D8D0"
            },
            "success": "#50FA7B",
            "warning": "#F1FA8C",
                "error": "#FF5555",
            "info": "#8BE9FD"
        },
        "typography": {
            "fontFamily": "Inter, -apple-system, BlinkMacSystemFont, Segoe UI",
            "fontSize": 14,
            "fontWeightLight": 300,
            "fontWeightRegular": 400,
            "fontWeightMedium": 500,
            "fontWeightBold": 700
        },
        "borderRadius": 6,
        "spacing": 8
    }
}


class ThemesManager:
    def __init__(self):
        self.custom_themes = {}
        self.themes = BUILT_IN_THEMES.copy()
    
    def list_themes(self) -> List[Dict[str, Any]]:
        """List all available themes"""
        return [
            {
                "id": theme_id,
                "name": theme["name"],
                "description": theme.get("description", ""),
                "isDark": theme.get("isDark", False),
                "type": "builtin"
            }
            for theme_id, theme in self.themes.items()
        ]
    
    def get_theme(self, theme_id: str) -> Optional[Dict[str, Any]]:
        """Get specific theme by ID"""
        if theme_id not in self.themes:
            return None
        
        return self.themes[theme_id]
    
    def create_theme(self, theme_data: Dict[str, Any]) -> Dict[str, Any]:
        """Create or update custom theme"""
        theme_id = theme_data.get("id")
        
        if not theme_id:
            raise ValueError("Theme ID is required")
        
        # Validate required fields
        required_fields = ["name", "palette", "isDark"]
        for field in required_fields:
            if field not in theme_data:
                raise ValueError(f"Required field missing: {field}")
        
        # Validate palette structure
        palette = theme_data.get("palette", {})
        required_palette = ["primary", "secondary", "background", "text"]
        for color in required_palette:
            if color not in palette:
                raise ValueError(f"Palette missing required color: {color}")
        
        # Add default values for optional fields
        if "description" not in theme_data:
            theme_data["description"] = ""
        if "typography" not in theme_data:
            theme_data["typography"] = BUILT_IN_THEMES["modern_dark"]["typography"].copy()
        if "borderRadius" not in theme_data:
            theme_data["borderRadius"] = 8
        if "spacing" not in theme_data:
            theme_data["spacing"] = 8
        
        theme_data["type"] = "custom"
        self.custom_themes[theme_id] = theme_data
        self.themes[theme_id] = theme_data
        
        return {
            "id": theme_id,
            "name": theme_data["name"],
            "description": theme_data.get("description", ""),
            "isDark": theme_data.get("isDark", False),
            "type": "custom",
            "created": True
        }
    
    def validate_theme(self, theme_data: Dict[str, Any]) -> Dict[str, Any]:
        """Validate theme configuration"""
        errors = []
        warnings = []
        
        # Check required fields
        if "name" not in theme_data:
            errors.append("Missing required field: name")
        if "palette" not in theme_data:
            errors.append("Missing required field: palette")
        if "isDark" not in theme_data:
            errors.append("Missing required field: isDark")
        
        # Validate palette
        if "palette" in theme_data:
            palette = theme_data["palette"]
            required_colors = ["primary", "secondary", "background", "text"]
            for color in required_colors:
                if color not in palette:
                    errors.append(f"Palette missing required color: {color}")
        
        # Validate color format
        if "palette" in theme_data:
            for color_name, color_value in theme_data["palette"].items():
                if isinstance(color_value, dict):
                    for variant, hex_color in color_value.items():
                        if not self._is_valid_hex_color(hex_color):
                            errors.append(f"Invalid hex color: {color_name}.{variant} = {hex_color}")
                elif isinstance(color_value, str):
                    if not self._is_valid_hex_color(color_value):
                        errors.append(f"Invalid hex color: {color_name} = {color_value}")
        
        return {
            "valid": len(errors) == 0,
            "errors": errors,
            "warnings": warnings
        }
    
    def _is_valid_hex_color(self, color: str) -> bool:
        """Check if color is valid hex format"""
        if not isinstance(color, str):
            return False
        color = color.lstrip("#")
        return len(color) in (3, 6, 8) and all(c in "0123456789ABCDEFabcdef" for c in color)


def main():
    """Plugin entry point"""
    parser = argparse.ArgumentParser()
    parser.add_argument("--request", required=True, help="JSON request")
    args = parser.parse_args()
    
    try:
        # Parse request
        request = json.loads(args.request)
        action = request.get("action")
        data = request.get("data", {})
        
        manager = ThemesManager()
        
        if action == "list_themes":
            themes = manager.list_themes()
            response = {
                "success": True,
                "data": {
                    "themes": themes,
                    "count": len(themes)
                }
            }
        
        elif action == "get_theme":
            theme_id = data.get("theme_id")
            if not theme_id:
                raise ValueError("theme_id is required")
            
            theme = manager.get_theme(theme_id)
            if not theme:
                raise ValueError(f"Theme not found: {theme_id}")
            
            response = {
                "success": True,
                "data": theme
            }
        
        elif action == "create_theme":
            theme_data = data.get("theme")
            if not theme_data:
                raise ValueError("theme data is required")
            
            created = manager.create_theme(theme_data)
            response = {
                "success": True,
                "data": created
            }
        
        elif action == "validate_theme":
            theme_data = data.get("theme")
            if not theme_data:
                raise ValueError("theme data is required")
            
            validation = manager.validate_theme(theme_data)
            response = {
                "success": validation["valid"],
                "data": validation
            }
        
        elif action == "info":
            response = {
                "success": True,
                "data": {
                    "name": "themes_extension",
                    "version": "1.0.0",
                    "author": "SentinelCore Team",
                    "description": "Provides additional UI themes and color schemes",
                    "builtin_themes": list(BUILT_IN_THEMES.keys()),
                    "capabilities": ["list_themes", "get_theme", "create_theme", "validate_theme"]
                }
            }
        
        else:
            response = {
                "success": False,
                "error": f"Unknown action: {action}"
            }
    
    except Exception as e:
        response = {
            "success": False,
            "error": str(e)
        }
    
    # Output response
    print(json.dumps(response))


if __name__ == "__main__":
    main()
